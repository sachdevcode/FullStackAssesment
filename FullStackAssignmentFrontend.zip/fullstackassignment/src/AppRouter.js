import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import SignIn from './components/SignIn/SignIn';
import MovieList from './components/MovieList/MovieList';
import MyMovies from './components/MyMovies/MyMovies';
import CreateMovie from './components/CreateMovies/CreateMovie';
import EditMovie from './components/EditMovies/EditMovies';

const AppRouter = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/signin" element={<SignIn />} />
        <Route path="/movies" element={<MovieList />} />
        <Route path="/my-movies" element={<MyMovies />} />
        <Route path="/create-movie" element={<CreateMovie />} />
        <Route path="/edit-movie/:id" element={<EditMovie />} />
        <Route path="/" element={<Navigate to="/signin" replace />} />
      </Routes>
    </BrowserRouter>
  );
};

export default AppRouter;