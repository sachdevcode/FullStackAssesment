import React, { useState, useEffect } from 'react';
import './EditMovies.css'; // Make sure to link this CSS file
import { useLocation, useNavigate } from 'react-router-dom';

const EditMovie = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const movieData = location.state?.movieData;

  const [movieTitle, setMovieTitle] = useState('');
  const [publishingYear, setPublishingYear] = useState('');
  const [image, setImage] = useState(null);

  useEffect(() => {
    if (movieData) {
      setMovieTitle(movieData.title);
      setPublishingYear(movieData.year);
      setImage(movieData.image);
    }
  }, [movieData]);

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImage(URL.createObjectURL(file));
    }
  };

  const handleSubmit = () => {
    navigate('/my-movies');
    // Handle form submission logic here
  };

  return (
    <div className="create-movie-container">
      <h2>Create a new movie</h2>
      <div className="movie-form">
        {/* Image Upload Section */}
        <div className="image-upload">
          <input 
            type="file" 
            accept="image/*"
            onChange={handleImageUpload} 
            id="image-input"
            style={{ display: 'none' }}
          />
          <label htmlFor="image-input" className="image-upload-label">
            {image ? (
              <img src={image} alt="movie" className="movie-image" />
            ) : (
              <div className="drop-zone">
                <p>Drop an image here</p>
              </div>
            )}
          </label>
        </div>
        
        {/* Input Fields Section */}
        <div className="input-fields">
          <input
            type="text"
            placeholder="Title"
            value={movieTitle}
            onChange={(e) => setMovieTitle(e.target.value)}
          />
          <input
            type="text"
            placeholder="Publishing year"
            value={publishingYear}
            onChange={(e) => setPublishingYear(e.target.value)}
          />
          <div className="buttons">
          <button className="cancel-btn">Cancel</button>
          <button className="submit-btn" onClick={handleSubmit}>Submit</button>
        </div>
        </div>

        {/* Buttons Section */}
        
      </div>
    </div>
  );
};

export default EditMovie;
