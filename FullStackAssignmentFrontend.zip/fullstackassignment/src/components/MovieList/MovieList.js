import React from 'react';
import './MovieList.css'; // Make sure to create and style the MovieListEmpty.css file
import { useNavigate } from 'react-router-dom';


const MovieList = () => {
  const navigate = useNavigate();

  return (
    <div className="movie-list-container">
      <div className="content">
        <h1>Your movie list is empty</h1>
        <button 
          className="add-movie-btn"
          onClick={() => navigate('/create-movie')}
        >Add a new movie</button>
      </div>
      {/* <footer className="footer">
        <div className="curve"></div>
      </footer> */}
    </div>
  );
};

export default MovieList;
