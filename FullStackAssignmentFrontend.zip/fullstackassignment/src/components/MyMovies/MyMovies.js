import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import './MyMovies.css'; // Make sure you include this CSS file for proper styling

const MyMovies = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [movies, setMovies] = useState(() => {
    const savedMovies = localStorage.getItem('movies');
    return savedMovies ? JSON.parse(savedMovies) : [
    { id: 1, title: 'Movie 1', year: 2021, image: 'https://picsum.photos/200/300' },
    { id: 2, title: 'Movie 2', year: 2021, image: 'https://via.placeholder.com/300x450?text=Movie+2' },
    { id: 3, title: 'Movie 3', year: 2021, image: 'https://via.placeholder.com/300x450?text=Movie+3' },
    { id: 4, title: 'Movie 4', year: 2021, image: 'https://via.placeholder.com/300x450?text=Movie+4' },
    { id: 5, title: 'Movie 5', year: 2021, image: 'https://via.placeholder.com/300x450?text=Movie+5' },
    { id: 6, title: 'Movie 6', year: 2021, image: 'https://via.placeholder.com/300x450?text=Movie+6' },
    { id: 7, title: 'Movie 7', year: 2021, image: 'https://via.placeholder.com/300x450?text=Movie+7' },
    { id: 8, title: 'Movie 8', year: 2021, image: 'https://via.placeholder.com/300x450?text=Movie+8' },
    ];
  });

  // Sample data for movies
  // const movies = [
  //   { title: 'Movie 1', year: 2021, image: 'https://via.placeholder.com/300x450?text=Movie+1' },
  //   { title: 'Movie 2', year: 2021, image: 'https://via.placeholder.com/300x450?text=Movie+2' },
  //   { title: 'Movie 3', year: 2021, image: 'https://via.placeholder.com/300x450?text=Movie+3' },
  //   { title: 'Movie 4', year: 2021, image: 'https://via.placeholder.com/300x450?text=Movie+4' },
  //   { title: 'Movie 5', year: 2021, image: 'https://via.placeholder.com/300x450?text=Movie+5' },
  //   { title: 'Movie 6', year: 2021, image: 'https://via.placeholder.com/300x450?text=Movie+6' },
  //   { title: 'Movie 7', year: 2021, image: 'https://via.placeholder.com/300x450?text=Movie+7' },
  //   { title: 'Movie 8', year: 2021, image: 'https://via.placeholder.com/300x450?text=Movie+8' },
  // ];


  useEffect(() => {
    if (location.state?.newMovie) {
      setMovies(prevMovies => {
        const movieExists = prevMovies.some(movie => 
          movie.title === location.state.newMovie.title
        );
        
        if (!movieExists) {
          const updatedMovies = [
            ...prevMovies,
            {
              id: prevMovies.length + 1,
              ...location.state.newMovie
            }
          ];
          // Save to localStorage
          localStorage.setItem('movies', JSON.stringify(updatedMovies));
          return updatedMovies;
        }
        return prevMovies;
      });
      
      window.history.replaceState({}, document.title);
    }
  }, [location.state]);

  useEffect(() => {
    localStorage.setItem('movies', JSON.stringify(movies));
  }, [movies]);

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const moviesPerPage = 8;

  // Logic for pagination
  const indexOfLastMovie = currentPage * moviesPerPage;
  const indexOfFirstMovie = indexOfLastMovie - moviesPerPage;
  const currentMovies = movies.slice(indexOfFirstMovie, indexOfLastMovie);

  // Handle page change
  const paginate = (pageNumber) => setCurrentPage(pageNumber);


  const handleMovieClick = (movie) => {
    navigate(`/edit-movie/${movie.id}`, { state: { movieData: movie } });
  };


  const handleLogout = () => {
    navigate('/signin');
  };

  return (
    <div className="my-movies-container">
      <div className="header">
        <div className="header-left">
          <h2>My movies</h2>
          <div className="add-icon" onClick={() => navigate('/create-movie')}>+</div>
        </div>
        <div className="header-right" onClick={handleLogout}>
          Logout <span className="logout-icon">→</span>
        </div>
      </div>

      <div className="movies-grid">
        {currentMovies.map((movie) => (
          <div 
            key={movie.id} 
            className="movie-card"
            onClick={() => handleMovieClick(movie)}
          >
            <img src={movie.image} alt={movie.title} className="movie-image" />
            <div className="movie-info">
              <h3>{movie.title}</h3>
              <p>{movie.year}</p>
            </div>
          </div>
        ))}
        </div>


        <div className="pagination">
        <button 
          onClick={() => paginate(currentPage - 1)} 
          disabled={currentPage === 1}
        >
          Prev
        </button>
        <span>Page {currentPage}</span>
        <button
          onClick={() => paginate(currentPage + 1)}
          disabled={currentPage * moviesPerPage >= movies.length}
        >
          Next
        </button>
      </div>
    </div>
  );
};

export default MyMovies;
