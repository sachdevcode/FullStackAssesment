const express = require('express');
const authController = require('../controllers/authController');

const router = express.Router();

// POST: Login with email and password
router.post('/login', authController.login);

// POST: Logout (invalidate JWT on client-side)
router.post('/logout', authController.logout);

module.exports = router;
