const express = require('express');
const multer = require('multer');
const path = require('path');
const movieController = require('../controllers/movieController');

const router = express.Router();

// Set up storage for uploaded posters (images)
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/'); // Store files in the 'uploads' folder
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname); // Get the file extension (e.g., .jpg, .png)
    const filename = Date.now() + ext; // Create a unique filename based on the timestamp
    cb(null, filename);
  },
});

const upload = multer({ storage });

// POST: Create a new movie (with poster image)
router.post('/movies', upload.single('poster'), movieController.createMovie);

// GET: Fetch all movies
router.get('/movies', movieController.getMovies);

// PUT: Update a movie (with poster image)
router.put('/movies/:id', upload.single('poster'), movieController.updateMovie);

// DELETE: Delete a movie
router.delete('/movies/:id', movieController.deleteMovie);

module.exports = router;
