const Movie = require('../models/Movie');
const path = require('path');

// Create a new movie with a poster (binary file upload)
const createMovie = async (req, res) => {
  const { title, publishingYear } = req.body;
  const poster = req.file ? req.file.path : ''; // Multer saves the file, and we get its path here

  const newMovie = new Movie({
    title,
    publishingYear,
    poster, // Store the path to the uploaded poster image
  });

  try {
    await newMovie.save();
    res.status(201).json(newMovie); // Return the created movie data
  } catch (error) {
    res.status(400).json({ message: error.message }); // Handle errors
  }
};

// Get all movies
const getMovies = async (req, res) => {
  try {
    const movies = await Movie.find();
    res.status(200).json(movies);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Update a movie (with poster image)
const updateMovie = async (req, res) => {
  const { id } = req.params;
  const { title, publishingYear } = req.body;
  const poster = req.file ? req.file.path : ''; // Multer saves the file and we get the path

  try {
    const updatedMovie = await Movie.findByIdAndUpdate(
      id,
      { title, publishingYear, poster },
      { new: true }
    );
    res.status(200).json(updatedMovie);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Delete a movie
const deleteMovie = async (req, res) => {
  const { id } = req.params;
  try {
    await Movie.findByIdAndDelete(id);
    res.status(200).json({ message: 'Movie deleted successfully' });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

module.exports = {
  createMovie,
  getMovies,
  updateMovie,
  deleteMovie,
};
