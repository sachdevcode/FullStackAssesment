const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Secret key for JWT token generation (store this securely in environment variables)
const JWT_SECRET = process.env.JWT_SECRET || 'your_secret_key'; 

// Login functionality: Validate user email & password and generate JWT token
const login = async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });

    if (!user) {
      return res.status(400).json({ message: 'User not found' });
    }

    const isMatch = await bcrypt.compare(password, user.password); // Compare password with hashed one

    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    // Generate JWT token with user info
    const token = jwt.sign({ userId: user._id, email: user.email }, JWT_SECRET, {
      expiresIn: '1h', // Token expiration time
    });

    res.status(200).json({ token }); // Send token to frontend for future authentication
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Logout functionality: Just send a success message as JWTs are stateless (client handles the token)
const logout = (req, res) => {
  // To log out, remove the token from client side (e.g., localStorage or cookies)
  res.status(200).json({ message: 'Logged out successfully' });
};

module.exports = { login, logout };
